# The Green Buffet — ordering & operations demo

Client demonstration prepared by **Altiora Technologies**. Not The Green Buffet's live system:
no orders reach the restaurant, no payments are taken, no messages are sent. All sales, stock
and feedback figures are labelled sample data.

## Stack
Vue 3 + TypeScript + Vite. Builds to one self-contained `dist/index.html` (hash routing, assets inlined),
so it runs on GitHub Pages or any static host. `src/services/backend.ts` stands in for the planned
FastAPI service and enforces the same rules (server-side pricing, role permissions, recipe stock
deduction, audit log). `src/services/api.ts` names the REST endpoint for every call, ready to swap for
`fetch()` against FastAPI + PostgreSQL.

## Run locally (PowerShell)
```
npm install
npm run dev
```

## Build and publish to GitHub Pages
```
npm run build
```
Push the contents of `dist/` (just `index.html`) to the `main` branch of a repo named `greenbuffet`,
then Settings → Pages → Deploy from branch → `main` / root.
Live at: https://joshuaalinanichishimba-cmyk.github.io/greenbuffet/

## Demo accounts (password `demo1234`)
admin@demo.gb · manager@demo.gb · kitchen@demo.gb · cashier@demo.gb

## Notes
- Data lives in each browser's localStorage. Reset from the Demo guide or Settings (manager/admin).
- Provisional values to confirm with the client: drink prices, topping list, sauce names,
  build-your-own bowl price (K75 assumed), topping overage rule.
