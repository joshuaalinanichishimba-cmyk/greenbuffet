# The Green Buffet — ordering & operations demo

Client demonstration prepared by **Altiora Technologies**. Not The Green Buffet's live system:
no orders reach the restaurant, no payments are taken, no messages are sent. All sales, stock
and feedback figures are labelled sample data.

## Stack
Vue 3 + TypeScript + Vite. Builds to one self-contained `dist/index.html` (hash routing, assets inlined),
so it runs on GitHub Pages or any static host. `src/services/backend.ts` stands in for the planned
FastAPI service and enforces the same rules (server-side pricing, role permissions, recipe stock
deduction, audit log). `src/services/api.ts` names the REST endpoint for every call, ready to swap for
`fetch()` against FastAPI + PostgreSQL.

## Run locally (PowerShell)
```
npm install
npm run dev
```

## Build and publish to GitHub Pages
```
npm run build
```
Push the contents of `dist/` (just `index.html`) to the `main` branch of a repo named `greenbuffet`,
then Settings → Pages → Deploy from branch → `main` / root.
Live at: https://joshuaalinanichishimba-cmyk.github.io/greenbuffet/

## Demo accounts (password `demo1234`)
admin@demo.gb · manager@demo.gb · kitchen@demo.gb · cashier@demo.gb

## Business features in this version
- Pause online ordering and live "ready in about N min" wait times (dashboard and kitchen)
- Kitchen prep list totalling everything still to make
- Promo codes with minimum spend and usage counts (sample: STUDENT10, LUNCH15)
- Loyalty stamps by phone number, free bowl applied automatically at checkout
- Cart upsells, menu search, homepage "try it" builder, one-tap reorder
- End-of-day cash-up report (printable) and restock shopping list
- Mobile tab bar for customers

## Payment gateway and WhatsApp/SMS (this version)
- Checkout: mobile money with automatic network detection (Airtel 097/077, MTN 096/076, Zamtel 095/075),
  Visa/Mastercard through a hosted sandbox page with 3-D Secure, or pay at the counter.
- Test cards: 4242 4242 4242 4242 approves, 4000 0000 0000 3220 asks for PIN 123456,
  4000 0000 0000 0002 is declined. Only these are accepted; never enter a real card.
- Admin Payments: ledger by network, illustrative fees, expected settlement, refunds.
- Customers opt in to WhatsApp or SMS updates. Messages are written to an outbox (Admin, Messages)
  and previewed on the tracking page; nothing is sent from the demo.
- All phone numbers display as 097 712 3456 and inputs format as you type.
- `server/` contains the FastAPI integration modules and `.env.example` for going live.

## Notes
- Data lives in each browser's localStorage. Reset from the Demo guide or Settings (manager/admin).
- Provisional values to confirm with the client: drink prices, topping list, sauce names,
  build-your-own bowl price (K75 assumed), topping overage rule.
